﻿namespace ehs1.Auth
{
    public class TokenModel
    {
        public string Token { get; set; }
    }
}
