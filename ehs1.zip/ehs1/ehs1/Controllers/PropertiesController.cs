﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ehs1.Models;

namespace ehs1.Controllers
{
    public class PropertiesController : Controller
    {
        private readonly Ehs1Context _context;

        public PropertiesController(Ehs1Context context)
        {
            _context = context;
        }

        // GET: Properties
        public async Task<IActionResult> Index(int? cityId)
        {
            var cities = await _context.Cities.ToListAsync();
            var properties = new List<Property>();

            if (cityId != null)
            {
                properties = await _context.Properties
                    .Where(p => p.CityId == cityId)
                    .Include(p => p.City)
                    .ToListAsync();
            }
            else
            {
                properties = await _context.Properties
                    .Include(p => p.City)
                    .ToListAsync();
            }

            // Assigning the sellerId
            var sellerId = 1;  // Replace this with the logic for fetching the sellerId based on your system
            ViewData["SellerId"] = sellerId;

            ViewData["Cities"] = cities;
            ViewData["SelectedCityId"] = cityId;

            return View(properties);
        }


        // GET: Properties/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var @property = await _context.Properties
                .Include(a => a.Seller)
                .FirstOrDefaultAsync(m => m.PropertyId == id);
            if (@property == null)
            {
                return NotFound();
            }

            return View(@property);
        }

        // GET: Properties/Verify/5
        public async Task<IActionResult> Verify(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var property = await _context.Properties.FindAsync(id);
            if (property == null)
            {
                return NotFound();
            }

            // Set the property as verified
            property.IsVerified = true;
            _context.Update(property);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        // GET: Properties/ByCity
        public async Task<IActionResult> ByCity(int? cityId)
        {
            // Fetch all cities for the filter dropdown asynchronously
            ViewBag.Cities = await _context.Cities.ToListAsync();

            // If no city is selected, return all properties
            if (!cityId.HasValue)
            {
                return View(await _context.Properties.Include(p => p.City).ToListAsync());
            }

            // Filter properties by CityId asynchronously
            var propertiesByCity = await _context.Properties
                .Where(p => p.CityId == cityId)
                .Include(p => p.City)  // Include the City navigation property for display
                .ToListAsync();

            return View(propertiesByCity);
        }

        // GET: Properties/ByOwner
        public async Task<IActionResult> ByOwner(int sellerId)
        {
            var propertiesByOwner = await _context.Properties
                .Where(p => p.SellerId == sellerId)
                .Include(p => p.Seller)
                .ToListAsync();

            return View(propertiesByOwner);
        }

        // GET: Properties/Create
        public IActionResult Create()

        {
            ViewData["SellerId"] = new SelectList(_context.Sellers, "SellerId", "SellerId");
            return View();
        }

        // POST: Properties/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
       
        public async Task<IActionResult> Create([Bind("PropertyId,PropertyName,PropertyType,PropertyOption,Description,Address,PriceRange,InitialDeposit,Landmark,IsActive,SellerId")] Property property, IFormFile[] images)
        {
            if (ModelState.IsValid)

            {
                property.IsActive = true;
                _context.Add(property);
                await _context.SaveChangesAsync();

                if (images != null && images.Length > 0)
                {
                    foreach (var image in images)
                    {
                        using (var memoryStream = new MemoryStream())
                        {
                            await image.CopyToAsync(memoryStream);  // Copy the image to memory stream

                            var propertyImage = new Image
                            {
                                PropertyId = property.PropertyId,
                                Image1 = memoryStream.ToArray()  // Store the byte array of the image
                            };

                            _context.Images.Add(propertyImage);
                            await _context.SaveChangesAsync();
                        }
                    }
                }

                return RedirectToAction(nameof(Index));
            }

            return View(property);
        }

        // GET: Properties/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var @property = await _context.Properties.FindAsync(id);
            if (@property == null)
            {
                return NotFound();
            }
            ViewData["CityId"] = new SelectList(await _context.Cities.ToListAsync(), "CityId", "CityName", @property.CityId);
            ViewData["SellerId"] = new SelectList(_context.Sellers, "SellerId", "SellerId", @property.SellerId);

            return View(@property);
        }

        // POST: Properties/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PropertyId,PropertyName,PropertyType,PropertyOption,Description,Address,PriceRange,InitialDeposit,Landmark,IsActive,SellerId,CityId")] Property @property)
        {
            if (id != @property.PropertyId)
            {
                return NotFound();
            }

            if (!ModelState.IsValid)
            {
                try
                {
                    _context.Update(@property);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PropertyExists(@property.PropertyId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CityId"] = new SelectList(await _context.Cities.ToListAsync(), "CityId", "CityName", @property.CityId);
            ViewData["SellerId"] = new SelectList(_context.Sellers, "SellerId", "SellerId", @property.SellerId);

            return View(@property);
        }

        // GET: Properties/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var @property = await _context.Properties
                .Include(a => a.Seller)
                .FirstOrDefaultAsync(m => m.PropertyId == id);
            if (@property == null)
            {
                return NotFound();
            }

            return View(@property);
        }

        // POST: Properties/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var @property = await _context.Properties.FindAsync(id);
            if (@property != null)
            {
                _context.Properties.Remove(@property);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        // GET: Properties/Verified
        public async Task<IActionResult> Verified(int sellerId)
        {
            var verifiedProperties = await _context.Properties
                .Where(p => p.SellerId == sellerId && p.IsVerified)
                .Include(p => p.Seller)
                .ToListAsync();

            return View(verifiedProperties);
        }

        // GET: Properties/Deactivated
        //public async Task<IActionResult> Deactivated(int sellerId)
        //{
        //    var deactivatedProperties = await _context.Properties
        //        .Where(p => p.SellerId == sellerId && !p.IsActive)
        //        .Include(p => p.Seller)
        //        .ToListAsync();

        //    return View(deactivatedProperties);
        //}

        public async Task<IActionResult> Deactivated(int sellerId)
        {
            var deactivatedProperties = await _context.Properties
                .Where(p => p.SellerId == sellerId && !p.IsActive)
                .Include(p => p.Seller)
                .ToListAsync();

            // Add logging to check the result
            Console.WriteLine($"Deactivated Properties Count: {deactivatedProperties.Count}");

            return View(deactivatedProperties);
        }


        // GET: Properties/Activated
        public async Task<IActionResult> Activated()
        {
            // Fetch all active properties for all sellers
            var activatedProperties = await _context.Properties
                .Where(p => p.IsActive) // Only active properties
                .Include(p => p.Seller) // Include Seller info for display
                .ToListAsync();

            // Pass the activated properties to the view
            return View(activatedProperties);
        }




        // Helper method to check if property exists
        private bool PropertyExists(int id)
        {
            return _context.Properties.Any(e => e.PropertyId == id);
        }
    }
}
