﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ehs1.Models;
using Microsoft.AspNetCore.Authorization;
using System.Data;
using ehs1;

namespace ehs1.Controllers
{
    [JWTAction]
    public class SellersController : Controller
    {
        private readonly Ehs1Context _context;

        public SellersController(Ehs1Context context)
        {
            _context = context;
        }
        [JWTAction(allowedRoles: "Seller,Admin")]
        public async Task<IActionResult> Index()
        {
            var sellerId = Convert.ToInt32(User.Identity.Name);

            // Fetching the current seller's details
            var seller = await _context.Sellers
                .Where(s => s.SellerId == sellerId)
                .Include(s => s.City)
                .Include(s => s.State)
                .ToListAsync();

            if (seller == null)
            {
                return NotFound();
            }

            return View(seller);
        }


        // View Verified Properties
        [HttpGet]
        public async Task<IActionResult> ViewVerifiedProperties()
        {
            var sellerId = Convert.ToInt32(User.Identity.Name);
            var verifiedProperties = await _context.Properties
                .Where(p => p.SellerId == sellerId && p.IsVerified)
                .Include(p => p.Images)
                .ToListAsync();
            return View(verifiedProperties);
        }

        [JWTAction(allowedRoles: "Seller,Admin")]
        public async Task<IActionResult> ViewDeactivatedProperties()
        {
            var sellerId = Convert.ToInt32(User.Identity.Name); // Convert User.Identity.Name to an integer
            var deactivatedProperties = _context.Properties
                .Where(p => p.SellerId == sellerId && !p.IsActive) // Now comparing the sellerId as an integer
                .Include(p => p.Images)
                .ToListAsync();
            return View(await deactivatedProperties);
        }

        [JWTAction(allowedRoles: "Seller,Admin")]
        public async Task<IActionResult> EditProperty(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sellerId = Convert.ToInt32(User.Identity.Name); // Convert User.Identity.Name to an integer
            var property = await _context.Properties
                .Include(p => p.Images)
                .FirstOrDefaultAsync(m => m.PropertyId == id && m.SellerId == sellerId); // Now comparing sellerId as an integer
            if (property == null)
            {
                return NotFound();
            }

            return View(property);
        }


        [JWTAction(allowedRoles: "Seller,Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditProperty(int id, [Bind("PropertyId,Title,Description,Price,Address,IsVerified,IsActive")] Property property)
        {
            if (id != property.PropertyId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(property);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PropertyExists(property.PropertyId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(ViewVerifiedProperties));
            }
            return View(property);
        }

        // Upload Images (Max 6 images per property)
        [JWTAction(allowedRoles: "Seller,Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UploadImages(int propertyId, List<IFormFile> images)
        {
            if (images.Count > 6)
            {
                ModelState.AddModelError("", "You can upload a maximum of 6 images.");
                return View();
            }
            var sellerId = Convert.ToInt32(User.Identity.Name); // Convert User.Identity.Name to an integer

            var property = await _context.Properties
                .FirstOrDefaultAsync(p => p.PropertyId == propertyId && p.SellerId == sellerId); // Compare with the integer sellerId

            if (property == null)
            {
                return NotFound();
            }

            foreach (var image in images)
            {
                if (image.Length > 0)
                {
                    var imageUrl = await SaveImageAsync(image); // A method to save the image to your file system or cloud storage.
                    var propertyImage = new PropertyImage
                    {
                        PropertyId = property.PropertyId,
                        ImageUrl = imageUrl
                    };
                    _context.PropertyImages.Add(propertyImage);
                }
            }
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(EditProperty), new { id = propertyId });
        }

        // Save image to the server (or cloud)
        private async Task<string> SaveImageAsync(IFormFile image)
        {
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/images", image.FileName);

            using (var fileStream = new FileStream(filePath, FileMode.Create))
            {
                await image.CopyToAsync(fileStream);
            }

            return "/images/" + image.FileName; // Returning the image URL
        }

        private bool PropertyExists(int id)
        {
            return _context.Properties.Any(e => e.PropertyId == id);
        }
    }
}
