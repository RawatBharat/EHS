﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ehs1.Migrations
{
    /// <inheritdoc />
    public partial class RecreateMigrations : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
