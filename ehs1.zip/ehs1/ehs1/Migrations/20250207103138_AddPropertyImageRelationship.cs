﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ehs1.Migrations
{
    /// <inheritdoc />
    public partial class AddPropertyImageRelationship : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "PropertyImage",
                columns: table => new
                {
                    PropertyImageId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PropertyId = table.Column<int>(type: "int", nullable: false),
                    ImageUrl = table.Column<string>(type: "varchar(250)", unicode: false, maxLength: 250, nullable: false),
                    PropertyImageId1 = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__PropertyImage__...", x => x.PropertyImageId);
                    table.ForeignKey(
                        name: "FK_PropertyImage_PropertyImage_PropertyImageId1",
                        column: x => x.PropertyImageId1,
                        principalTable: "PropertyImage",
                        principalColumn: "PropertyImageId");
                    table.ForeignKey(
                        name: "FK__PropertyImage__Property__...",
                        column: x => x.PropertyId,
                        principalTable: "Property",
                        principalColumn: "PropertyId");
                });

            migrationBuilder.CreateIndex(
                name: "IX_PropertyImage_PropertyId",
                table: "PropertyImage",
                column: "PropertyId");

            migrationBuilder.CreateIndex(
                name: "IX_PropertyImage_PropertyImageId1",
                table: "PropertyImage",
                column: "PropertyImageId1");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PropertyImage");
        }
    }
}
