﻿using Microsoft.EntityFrameworkCore;

namespace ehs1.Models;

public partial class Ehs1Context : DbContext
{
    public Ehs1Context()
    {
    }

    public Ehs1Context(DbContextOptions<Ehs1Context> options)
        : base(options)
    {
    }

    public virtual DbSet<Buyer> Buyers { get; set; }
    public virtual DbSet<Cart> Carts { get; set; }
    public virtual DbSet<City> Cities { get; set; }
    public virtual DbSet<Image> Images { get; set; }
    public virtual DbSet<Property> Properties { get; set; }
    public virtual DbSet<Seller> Sellers { get; set; }
    public virtual DbSet<State> States { get; set; }
    public virtual DbSet<User> Users { get; set; }
    public virtual DbSet<PropertyImage> PropertyImages { get; set; }  // Add DbSet for PropertyImage

    //public virtual DbSet<PropertyImage> PropertyImages { get; set; }  // Add DbSet for PropertyImage


    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("Server=INBLRVM26590142;Database=ehs1;Trusted_Connection=True;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Buyer>(entity =>
        {
            entity.HasKey(e => e.BuyerId).HasName("PK__Buyer__4B81C62A0FEB44C1");
            entity.ToTable("Buyer");
            entity.Property(e => e.EmailId).HasMaxLength(50).IsUnicode(false);
            entity.Property(e => e.FirstName).HasMaxLength(25).IsUnicode(false);
            entity.Property(e => e.LastName).HasMaxLength(25).IsUnicode(false);
            entity.Property(e => e.PhoneNo).HasMaxLength(10).IsUnicode(false);
        });

        modelBuilder.Entity<Cart>(entity =>
        {
            entity.HasKey(e => e.CartId).HasName("PK__Cart__51BCD7B7AD295EEF");
            entity.ToTable("Cart");

            entity.HasOne(d => d.Buyer)
                .WithMany(p => p.Carts)
                .HasForeignKey(d => d.BuyerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Cart__BuyerId__37A5467C");

            entity.HasOne(d => d.Property)
                .WithMany(p => p.Carts)
                .HasForeignKey(d => d.PropertyId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Cart__PropertyId__38996AB5");
        });

        modelBuilder.Entity<City>(entity =>
        {
            entity.HasKey(e => e.CityId).HasName("PK__City__F2D21B76AB042EA8");
            entity.ToTable("City");
            entity.Property(e => e.CityName).HasMaxLength(50).IsUnicode(false);

            entity.HasOne(d => d.State)
                .WithMany(p => p.Cities)
                .HasForeignKey(d => d.StateId)
                .HasConstraintName("FK__City__StateId__29572725");
        });

        modelBuilder.Entity<Image>(entity =>
        {
            entity.HasKey(e => e.ImageId).HasName("PK__Images__7516F70C1C809CF3");
            entity.Property(e => e.Image1).HasColumnName("Image");

            entity.HasOne(d => d.Property)
                .WithMany(p => p.Images)
                .HasForeignKey(d => d.PropertyId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Images__Property__34C8D9D1");
        });

        modelBuilder.Entity<Property>(entity =>
        {
            entity.HasKey(e => e.PropertyId).HasName("PK__Property__70C9A735B233829D");
            entity.ToTable("Property");

            entity.Property(e => e.Address).HasMaxLength(250).IsUnicode(false);
            entity.Property(e => e.Description).HasMaxLength(250).IsUnicode(false);
            entity.Property(e => e.InitialDeposit).HasColumnType("money");
            entity.Property(e => e.Landmark).HasMaxLength(25).IsUnicode(false);
            entity.Property(e => e.PriceRange).HasColumnType("money");
            entity.Property(e => e.PropertyName).HasMaxLength(50).IsUnicode(false);
            entity.Property(e => e.PropertyOption).HasMaxLength(10).IsUnicode(false);
            entity.Property(e => e.PropertyType).HasMaxLength(15).IsUnicode(false);

            entity.HasOne(d => d.Seller)
                .WithMany(p => p.Properties)
                .HasForeignKey(d => d.SellerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Property__Seller__31EC6D26");
        });

        modelBuilder.Entity<Seller>(entity =>
        {
            entity.HasKey(e => e.SellerId).HasName("PK__Seller__7FE3DB815D2129C5");
            entity.ToTable("Seller");

            entity.Property(e => e.Address).HasMaxLength(250).IsUnicode(false);
            entity.Property(e => e.EmailId).HasMaxLength(50).IsUnicode(false);
            entity.Property(e => e.FirstName).HasMaxLength(25).IsUnicode(false);
            entity.Property(e => e.LastName).HasMaxLength(25).IsUnicode(false);
            entity.Property(e => e.PhoneNo).HasMaxLength(10).IsUnicode(false);
            entity.Property(e => e.UserName).HasMaxLength(25).IsUnicode(false);

            entity.HasOne(d => d.City)
                .WithMany(p => p.Sellers)
                .HasForeignKey(d => d.CityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Seller__CityId__2D27B809");

            entity.HasOne(d => d.State)
                .WithMany(p => p.Sellers)
                .HasForeignKey(d => d.StateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Seller__StateId__2C3393D0");
        });

        modelBuilder.Entity<State>(entity =>
        {
            entity.HasKey(e => e.StateId).HasName("PK__State__C3BA3B3A23C748D0");
            entity.ToTable("State");

            entity.Property(e => e.StateName).HasMaxLength(30).IsUnicode(false);
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.UserName).HasName("PK__Users__C9F28457F0258985");
            entity.Property(e => e.UserName).HasMaxLength(25).IsUnicode(false);
            entity.Property(e => e.Password).HasMaxLength(25).IsUnicode(false);
            entity.Property(e => e.UserType).HasMaxLength(15).IsUnicode(false);
        });

        // Add PropertyImage mapping here
        modelBuilder.Entity<PropertyImage>(entity =>
        {
            entity.HasKey(e => e.PropertyImageId).HasName("PK__PropertyImage__...");
            entity.ToTable("PropertyImage");
            entity.Property(e => e.ImageUrl).HasMaxLength(250).IsUnicode(false);

            // Define the foreign key relationship to Property
            entity.HasOne(d => d.Property)
                .WithMany(p => p.PropertyImages)
                .HasForeignKey(d => d.PropertyId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__PropertyImage__Property__...");
        });


        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
