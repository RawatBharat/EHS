﻿namespace ehs1.Models
{
    public partial class Property
    {
        public int PropertyId { get; set; }
        public string PropertyName { get; set; } = null!;
        public string PropertyType { get; set; } = null!;
        public string PropertyOption { get; set; } = null!;
        public string? Description { get; set; }
        public string Address { get; set; } = null!;
        public decimal PriceRange { get; set; }
        public decimal InitialDeposit { get; set; }
        public string Landmark { get; set; } = null!;
        public bool IsActive { get; set; }
        public bool IsVerified { get; set; }

        public int SellerId { get; set; }
        public virtual Seller Seller { get; set; } = null!;

        // Add CityId property as foreign key to City table
        public int CityId { get; set; }
        public virtual City City { get; set; } = null!; // Navigation property to City

        public virtual ICollection<Image> Images { get; set; } = new List<Image>();
        public virtual ICollection<Cart> Carts { get; set; } = new List<Cart>();

        // Initialize PropertyImages collection to avoid null reference errors
        public virtual ICollection<PropertyImage> PropertyImages { get; set; } = new List<PropertyImage>();
    }
}
