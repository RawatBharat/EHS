﻿namespace ehs1.Models
{
    public partial class PropertyImage
    {
        public int PropertyImageId { get; set; }  // Primary Key
        public int PropertyId { get; set; }  // Foreign Key to Property
        public string ImageUrl { get; set; } = null!;  // Image URL or path to the image

        // Navigation property to the Property entity
        public virtual Property Property { get; set; } = null!;
        public virtual ICollection<PropertyImage> PropertyImages { get; set; } = new List<PropertyImage>();  // Navigation to PropertyImage

    }
}
