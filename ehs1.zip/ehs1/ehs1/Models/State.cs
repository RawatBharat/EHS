﻿using System;
using System.Collections.Generic;

namespace ehs1.Models;

public partial class State
{
    public int StateId { get; set; }

    public string? StateName { get; set; }

    public virtual ICollection<City> Cities { get; set; } = new List<City>();

    public virtual ICollection<Seller> Sellers { get; set; } = new List<Seller>();
}
